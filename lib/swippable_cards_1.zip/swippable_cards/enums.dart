enum SwipeType { none, swipe, back, undo, move }
